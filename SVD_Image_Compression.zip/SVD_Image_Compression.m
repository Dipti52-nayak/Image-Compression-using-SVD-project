clc;
clear;
close all;

% Step 1: Download image using URL
imageURL = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkMNlJ797U0l4qUyzyha6HiinnaE5Fu8oDM4A3KArrhPuEFyEBf14BNdrf&s=10';

websave('input_image.jpg', imageURL);

% Step 2: Read the image
img = imread('input_image.jpg');

% Step 3: Convert image into grayscale
if size(img, 3) == 3
    img = rgb2gray(img);
end

% Convert image into double format
A = im2double(img);

% Step 4: Apply Singular Value Decomposition
[U, S, V] = svd(A, 'econ');

% Step 5: Select different K values
kValues = [5 10 20 50 100];

% Adjust K values according to image size
maxK = min(size(A));
kValues = kValues(kValues <= maxK);

if isempty(kValues)
    error('Image is too small for the selected K values.');
end

% Step 6: Display original image
figure;

subplot(2, 3, 1);
imshow(A);
title('Original Image');

% Step 7: Image compression using SVD
errors = zeros(size(kValues));
ratios = zeros(size(kValues));

for i = 1:length(kValues)

    k = kValues(i);

    % Reconstruct compressed image
    compressedImage = U(:,1:k) * ...
                      S(1:k,1:k) * ...
                      V(:,1:k)';

    % Display compressed image
    subplot(2, 3, i+1);
    imshow(compressedImage, []);
    title(['Compressed Image K = ', num2str(k)]);

    % Step 8: Calculate reconstruction error
    errors(i) = norm(A - compressedImage, 'fro') / ...
                norm(A, 'fro');

    % Step 9: Calculate compression ratio
    originalSize = numel(A);
    compressedSize = k * (size(A,1) + size(A,2) + 1);

    ratios(i) = originalSize / compressedSize;

end

% Step 10: Display results
fprintf('\nSVD IMAGE COMPRESSION RESULTS\n');

for i = 1:length(kValues)

    fprintf('\nK Value: %d\n', kValues(i));
    fprintf('Reconstruction Error: %.4f\n', errors(i));
    fprintf('Compression Ratio: %.2f\n', ratios(i));

end

% Step 11: Plot reconstruction error
figure;

plot(kValues, errors, '-o', ...
     'LineWidth', 2);

xlabel('K Values');
ylabel('Reconstruction Error');
title('SVD Image Compression Error');
grid on;

% Step 12: Plot compression ratio
figure;

plot(kValues, ratios, '-o', ...
     'LineWidth', 2);

xlabel('K Values');
ylabel('Compression Ratio');
title('SVD Compression Ratio');
grid on;